module.exports = client => {
  console.log(`Sistem Kapatıldı! ${new Date()}`);
};
